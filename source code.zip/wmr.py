import pygame
import time
import pyvjoy
import tkinter as tk
from tkinter import simpledialog, messagebox
from tkinter import Toplevel, Scrollbar, Frame
from threading import Thread
import json
import os
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import keyboard
import webbrowser

# Initialize pygame for controller handling
pygame.init()
pygame.joystick.init()

# Tkinter UI setup
root = tk.Tk()
root.title("Wheelmode and Reverse")

# Error handling for vJoy device availability
try:
    vj = pyvjoy.VJoyDevice(1)
except pyvjoy.exceptions.vJoyFailedToAcquireException:
    messagebox.showerror("Error", "VJoy device 1 is already in use")
    root.quit()
except Exception as e:
    # Handle other potential exceptions, including when no vJoy device is found
    if "No VJD" in str(e) or "VJD does not exist" in str(e):
        messagebox.showerror("Error", "No vJoy device found")
        root.quit()
    else:
        raise  # Re-raise any other unexpected exceptions

# Ensure the application closes fully when the X button is pressed
root.protocol("WM_DELETE_WINDOW", root.quit)

# Global variable to track reverse state
reverse_active = False

# Store the current X axis value
current_x_axis_value = 0

# Default settings
default_settings = {
    "button_binding": 1,  # B button on Xbox Controller, Triangle on Wheel
    "linearity": 100,
    "wheelmode_enabled": True,
    "clutch_axis": "RX Axis",  # Default clutch axis
    "reverse_button": 9,  # Default reverse button
    "keyboard_clutch": "0",  # Default keyboard clutch
    "keyboard_gear5": "9", # Default keyboard gear 5
    "smoothing": 0
}

# Function to load settings from a file
def load_settings(device_name, profile_name="default"):
    settings_file = f"{device_name}_{profile_name}_settings.json"
    if os.path.exists(settings_file):
        with open(settings_file, 'r') as f:
            return json.load(f)
    return default_settings.copy()  # Return default settings

# Function to save settings to a file
def save_settings(device_name, settings, profile_name="default"):
    settings_file = f"{device_name}_{profile_name}_settings.json"
    with open(settings_file, 'w') as f:
        json.dump(settings, f)

# Function to save the selected device and profile
def save_selected_device_and_profile(device_name, profile_name):
    with open("selected_device.json", 'w') as f:
        json.dump({"selected_device": device_name, "selected_profile": profile_name}, f)

# Function to load the selected device and profile
def load_selected_device_and_profile():
    if os.path.exists("selected_device.json"):
        with open("selected_device.json", 'r') as f:
            data = json.load(f)
            return data.get("selected_device", "Select Controller"), data.get("selected_profile", "default")
    return "Select Controller", "default"

# Function to rename the current profile, including the default one
def rename_profile():
    current_profile = profile_var.get()
    new_name = simpledialog.askstring("Rename Profile", f"Enter a new name for the profile '{current_profile}':")
    if new_name and not os.path.exists(f"{controller_var.get()}_{new_name}_settings.json"):
        os.rename(f"{controller_var.get()}_{current_profile}_settings.json",
                  f"{controller_var.get()}_{new_name}_settings.json")
        profile_var.set(new_name)
        update_profile_menu(new_name)
    elif os.path.exists(f"{controller_var.get()}_{new_name}_settings.json"):
        tk.messagebox.showerror("Error", f"The profile '{new_name}' already exists. Please choose a different name.")

# Function to update the profile menu to reflect the new name
def update_profile_menu(new_name):
    profile_menu['menu'].delete(0, 'end')
    profiles = [f.replace(f"{controller_var.get()}_", "").replace("_settings.json", "") for f in os.listdir(".") if f.startswith(controller_var.get())]
    for profile in profiles:
        profile_menu['menu'].add_command(label=profile, command=lambda p=profile: profile_var.set(p))
    profile_var.set(new_name)

# Function to create a new profile
def create_new_profile():
    new_profile_name = simpledialog.askstring("Create New Profile", "Enter a name for the new profile:")
    if new_profile_name and not os.path.exists(f"{controller_var.get()}_{new_profile_name}_settings.json"):
        profile_var.set(new_profile_name)
        save_settings(controller_var.get(), settings, new_profile_name)
        update_profile_menu(new_profile_name)
    elif os.path.exists(f"{controller_var.get()}_{new_profile_name}_settings.json"):
        tk.messagebox.showerror("Error", f"The profile '{new_profile_name}' already exists. Please choose a different name.")

# UI for device and profile management at the top
top_frame = tk.Frame(root)
top_frame.pack(pady=10)

# Dropdown menu for selecting the controller
controller_var = tk.StringVar(root)
selected_device_name, selected_profile_name = load_selected_device_and_profile()
controller_var.set(selected_device_name)

# Get the list of connected controllers excluding vJoy
controllers = [pygame.joystick.Joystick(i) for i in range(pygame.joystick.get_count())]
controller_names = [controller.get_name() for controller in controllers if "vJoy" not in controller.get_name()]
for controller in controllers:
    controller.init()

if selected_device_name not in controller_names:
    controller_var.set("Select Controller")

controller_menu = tk.OptionMenu(top_frame, controller_var, *controller_names)
controller_menu.pack(side=tk.LEFT, padx=(10, 5))

# Profile management
profile_var = tk.StringVar(root)
profile_var.set(selected_profile_name)
profile_menu = tk.OptionMenu(top_frame, profile_var, "default")
profile_menu.pack(side=tk.LEFT, padx=(5, 5))

# Button for renaming the current profile
rename_profile_button = tk.Button(top_frame, text="Rename Current Profile", command=rename_profile)
rename_profile_button.pack(side=tk.LEFT, padx=(5, 5))

# Button for creating a new profile
new_profile_button = tk.Button(top_frame, text="New Profile", command=create_new_profile)
new_profile_button.pack(side=tk.LEFT, padx=(5, 10))

# Function to display the Information window
def show_information():
    info_window = Toplevel(root)
    info_window.title("Information")

    # Make the window resizable
    info_window.geometry("405x400")
    info_window.minsize(405, 400)

    # Create a frame to hold the content and scrollbar
    content_frame = Frame(info_window)
    content_frame.pack(fill="both", expand=True)

    # Add a canvas to allow scrolling
    canvas = tk.Canvas(content_frame)
    canvas.pack(side="left", fill="both", expand=True)

    # Add a scrollbar
    scrollbar = Scrollbar(content_frame, orient="vertical", command=canvas.yview)
    scrollbar.pack(side="right", fill="y")

    # Create a frame inside the canvas to hold the text
    scrollable_frame = tk.Frame(canvas)

    # Bind the scrollbar to the canvas
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    # Function to update the scroll region when resizing
    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    scrollable_frame.bind("<Configure>", on_frame_configure)

    # Enable mousewheel scrolling inside the canvas
    def on_mousewheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    info_window.bind_all("<MouseWheel>", on_mousewheel)  # For Windows
    info_window.bind_all("<Button-4>", on_mousewheel)    # For Linux
    info_window.bind_all("<Button-5>", on_mousewheel)    # For Linux

    # Function to update the scroll region when resizing
    def on_frame_configure(event):
        canvas.configure(scrollregion=canvas.bbox("all"))

    scrollable_frame.bind("<Configure>", on_frame_configure)

    # Add Headers and Placeholder Text
    headers = ["Requirements", "Suggested Settings", "Profiles", "Linearity", "Smoothing", "Reverse", "Help"]
    placeholder_text = {
        "Requirements": "To use this Software, you will have to have Vjoy installed and configured in Regedit to appear as a Steering Wheel in game. Make sure to also unbind Steer Left and right for your Controller and bind it for Vjoy. After you have done it, choose your controller device at the Top Left corner of the Main Window of this Software.",
        "Suggested Settings": "For People new to Wheelmode, I highly Recommend 75 Linearity with 0 smoothing, yet if you cant control it, use 85 Linearity with 0.7-1 smoothing. If ur pro use 0 Smoothing with 100 Linearity",
        "Profiles": "Profiles allow you to create different settings and change between them quickly instead of having to change all values. After changing a Profile, restart the Software to fix the flashing Graph. (idk how to fix)",
        "Linearity": "With this option you can choose the Linearity you want to use. Values range from 50 to 150. A Value below 100 will give you less input at small steering angles and will exponentially grow. A Value above 100 will give more Steering Output at small Angles and exponentially less the more you steer.",
        "Smoothing": "Smoothing Values range from 0 to 1 and allow you to delay your Steering input aka smooth it out if you are not used to Wheelmode yet.",
        "Reverse": "When holding down your binded reverse button, you will get a clutch axis output and a button output through vjoy (Clutch + Reverse). Upon Release, you will get 2 Keyboard outputs (Clutch + Gear 1-7). This will help you perform the Reverse glitch to preserve your Speed.",
        "Help": "If you need further assistance, feel free to dm @flicction on Discord"
    }

    for header in headers:
        # Create a bold header label
        header_label = tk.Label(scrollable_frame, text=header, font=("Helvetica", 14, "bold"), anchor="w", padx=10)
        header_label.pack(fill="x", pady=(10, 0))
        
        # Create a normal-sized label for the placeholder text, with wraplength based on window width
        text_label = tk.Label(scrollable_frame, text=placeholder_text[header], font=("Helvetica", 12), anchor="w", padx=10, justify="left", wraplength=380)
        text_label.pack(fill="x", pady=(0, 10))

# Adding the hover information effect
def create_info_button():
    info_button = tk.Button(top_frame, text="Info", font=("Helvetica", 14), command=show_information)
    info_button.pack(side=tk.RIGHT, padx=(5, 10))

# Call this function to add the "i" button
create_info_button()

# UI Initialization (other UI components like the profile, linearity, smoothing etc. should go here)
def initialize_ui():
    global top_frame
    top_frame = tk.Frame(root)
    top_frame.pack(pady=10)

    # Add the "i" information button
    create_info_button()

# Load settings for the selected controller
settings = load_settings(controller_var.get(), profile_var.get())
button_binding = settings.get("button_binding", default_settings["button_binding"])
linearity_value = settings.get("linearity", default_settings["linearity"])
wheelmode_enabled = settings.get("wheelmode_enabled", default_settings["wheelmode_enabled"])

# Function to update the selected device in the UI and settings
def update_selected_device_and_profile(*args):
    device_name = controller_var.get()
    profile_name = profile_var.get()
    save_selected_device_and_profile(device_name, profile_name)
    global settings, button_binding, linearity_value, wheelmode_enabled
    settings = load_settings(device_name, profile_name)
    button_binding = settings.get("button_binding", default_settings["button_binding"])
    linearity_value = settings.get("linearity", default_settings["linearity"])
    wheelmode_enabled = settings.get("wheelmode_enabled", default_settings["wheelmode_enabled"])
    linearity_entry.delete(0, tk.END)
    linearity_entry.insert(0, str(linearity_value))
    current_binding_label.config(text=f"Current Binding: Button {button_binding}")
    wheelmode_checkbutton_var.set(wheelmode_enabled)
    wheelmode_checkbutton.config(text="(ON)" if wheelmode_enabled else "(OFF)", fg="green" if wheelmode_enabled else "red")
    update_graph()

controller_var.trace("w", update_selected_device_and_profile)
profile_var.trace("w", update_selected_device_and_profile)

# Wheelmode and Reverse labels
frame = tk.Frame(root)
frame.pack(pady=10)

wheelmode_label = tk.Label(frame, text="Wheelmode", font=("Helvetica", 16))
wheelmode_label.grid(row=0, column=0, padx=5)

wheelmode_checkbutton_var = tk.BooleanVar(value=wheelmode_enabled)
wheelmode_checkbutton = tk.Checkbutton(frame, text="(ON)" if wheelmode_enabled else "(OFF)", variable=wheelmode_checkbutton_var, command=lambda: toggle_wheelmode(wheelmode_checkbutton), fg="green" if wheelmode_enabled else "red")
wheelmode_checkbutton.grid(row=0, column=1, padx=5)

reverse_label_title = tk.Label(frame, text="Reverse", font=("Helvetica", 16))
reverse_label_title.grid(row=0, column=2, padx=5)

reverse_status_label = tk.Label(frame, text="(Inactive)", font=("Helvetica", 16), fg="red")
reverse_status_label.grid(row=0, column=3, padx=5)

# Linearity label and input
linearity_label = tk.Label(frame, text="Linearity", font=("Helvetica", 12))
linearity_label.grid(row=2, column=0, padx=5, pady=5)
linearity_entry = tk.Entry(frame, width=5)
linearity_entry.insert(0, str(linearity_value))
linearity_entry.grid(row=3, column=0, padx=5, pady=5)

# Function to save the smoothing value dynamically and reset if out of bounds
def save_smoothing(event):
    try:
        smoothing = float(smoothing_entry.get())
        if smoothing > 1.0:
            smoothing = 1.0  # Reset to maximum if above 1.0
            smoothing_entry.delete(0, tk.END)
            smoothing_entry.insert(0, "1.0")
        smoothing = max(0.0, min(smoothing, 1.0))  # Clamp between 0 and 1
        settings["smoothing"] = smoothing
        save_settings(controller_var.get(), settings, profile_var.get())
    except ValueError:
        pass  # Ignore invalid values

# Adding Smoothing Entry to the UI
def add_smoothing_entry_to_ui():
    global smoothing_entry

    smoothing_label = tk.Label(frame, text="Smoothing", font=("Helvetica", 12))
    smoothing_label.grid(row=4, column=0, padx=5, pady=5)
    
    smoothing_entry = tk.Entry(frame, width=5)
    smoothing_entry.insert(0, str(settings.get("smoothing", 0.5)))  # Default smoothing factor
    smoothing_entry.grid(row=5, column=0, padx=5, pady=5)
    
    # Event listener for instant saving of smoothing value
    smoothing_entry.bind("<KeyRelease>", save_smoothing)

# Update load_settings function to include smoothing
def load_settings(device_name, profile_name="default"):
    settings_file = f"{device_name}_{profile_name}_settings.json"
    if os.path.exists(settings_file):
        with open(settings_file, 'r') as f:
            return json.load(f)
    default_settings = {
        "button_binding": 1,
        "linearity": 100,
        "wheelmode_enabled": True,
        "clutch_axis": "RX Axis",
        "reverse_button": 9,
        "keyboard_clutch": "0",
        "keyboard_gear5": "9",
        "smoothing": 0  # Default smoothing factor
    }
    return default_settings.copy()

# Button to bind reverse action
bind_button = tk.Button(frame, text="Bind Reverse", command=lambda: bind_reverse_action())
bind_button.grid(row=2, column=2, pady=10)

# Label to show the current button binding for reverse
current_binding_label = tk.Label(frame, text=f"Current Binding: Button {button_binding}", font=("Helvetica", 12))
current_binding_label.grid(row=3, column=2, pady=5)

# Matplotlib figure for the linearity curve
fig, ax = plt.subplots(figsize=(5, 2))
canvas = FigureCanvasTkAgg(fig, master=root)
canvas.get_tk_widget().pack()

# Function to update the graph based on linearity and show the current X axis position
def update_graph():
    try:
        linearity = int(linearity_entry.get())
        linearity = max(50, min(linearity, 150))  # Clamp between 1 and 100
        settings["linearity"] = linearity
        save_settings(controller_var.get(), settings, profile_var.get())

        x = np.linspace(-1, 1, 100)
        y = np.abs(x) ** (100 / linearity)  # Apply linearity curve

        ax.clear()
        ax.plot(x, y)
        ax.set_title("Linearity Curve")

        # Add a line for the current steering output
        current_output = (current_x_axis_value + 1) / 2  # Normalize to 0 to 1
        ax.axvline(current_x_axis_value, color='r', linestyle='--')

        canvas.draw()
    except ValueError:
        pass

# Call the update_graph function initially to show the graph
update_graph()

# Function to update the steering visualization
def update_steering_visualization(x_axis_output):
    global current_x_axis_value
    current_x_axis_value = x_axis_output
    update_graph()

# Function to handle the Reverse activation event
def on_reverse_activate():
    global reverse_active
    if not reverse_active:
        reverse_active = True
        press_rx_and_button_9()  # Hold Clutch axis and press Reverse button
        reverse_status_label.config(text="(Active)", fg="green")

# Function to handle the Reverse deactivation event
def on_reverse_deactivate():
    global reverse_active
    if reverse_active:
        reverse_active = False
        release_rx_and_button_9()  # Release Clutch axis and Reverse button
        reverse_status_label.config(text="(Inactive)", fg="red")
        
        # After 30ms, press the custom keys simultaneously using the keyboard library
        time.sleep(0.03)
        keyboard.press(settings["keyboard_clutch"])
        keyboard.press(settings["keyboard_gear5"])
        time.sleep(0.03)  # Hold the keys down for a short duration
        keyboard.release(settings["keyboard_clutch"])
        keyboard.release(settings["keyboard_gear5"])

# Function to press and hold the Clutch axis and Reverse button
def press_rx_and_button_9():
    axis_map = {
        "RX Axis": pyvjoy.HID_USAGE_RX,
        "RY Axis": pyvjoy.HID_USAGE_RY,
        "RZ Axis": pyvjoy.HID_USAGE_RZ,
    }
    vj.set_axis(axis_map[settings["clutch_axis"]], 0x8000)  # Maximum value for the selected axis
    vj.set_button(settings["reverse_button"], 1)  # Press the selected reverse button

# Function to release the Clutch axis and Reverse button
def release_rx_and_button_9():
    axis_map = {
        "RX Axis": pyvjoy.HID_USAGE_RX,
        "RY Axis": pyvjoy.HID_USAGE_RY,
        "RZ Axis": pyvjoy.HID_USAGE_RZ,
    }
    vj.set_axis(axis_map[settings["clutch_axis"]], 0x4000)  # Neutral position for the selected axis
    vj.set_button(settings["reverse_button"], 0)  # Release the selected reverse button

# Function to bind the reverse action to a button
def bind_reverse_action():
    def on_button_press(event):
        global button_binding
        button_binding = event.button
        settings["button_binding"] = button_binding
        save_settings(controller_var.get(), settings, profile_var.get())
        bind_button_window.destroy()
        current_binding_label.config(text=f"Current Binding: Button {button_binding}")

    selected_controller_name = controller_var.get()
    if selected_controller_name != "Select Controller":
        selected_controller = None
        for controller in controllers:
            if controller.get_name() == selected_controller_name:
                selected_controller = controller
                break

        if selected_controller:
            bind_button_window = tk.Toplevel(root)
            bind_button_window.title("Press any button to bind")
            bind_button_label = tk.Label(bind_button_window, text="Press the button you want to bind", font=("Helvetica", 16))
            bind_button_label.pack(pady=20)

            def check_button_press():
                pygame.event.pump()
                for i in range(selected_controller.get_numbuttons()):
                    if selected_controller.get_button(i):
                        on_button_press(pygame.event.Event(pygame.JOYBUTTONDOWN, button=i))
                        return
                bind_button_window.after(100, check_button_press)

            bind_button_window.after(100, check_button_press)

# Function to open the reverse bindings window
def open_reverse_bindings_window():
    reverse_window = tk.Toplevel(root)
    reverse_window.title("Change Reverse Bindings")

    # Clutch Dropdown
    tk.Label(reverse_window, text="Clutch").grid(row=0, column=0, padx=5, pady=5)
    clutch_var = tk.StringVar(reverse_window)
    clutch_var.set(settings.get("clutch_axis", "RX Axis"))  # Default to RX Axis (Axis 3)
    clutch_menu = tk.OptionMenu(reverse_window, clutch_var, *["RX Axis", "RY Axis", "RZ Axis"])
    clutch_menu.grid(row=0, column=1, padx=5, pady=5)

    # Reverse Button Dropdown
    tk.Label(reverse_window, text="Reverse").grid(row=1, column=0, padx=5, pady=5)
    reverse_button_var = tk.IntVar(reverse_window)
    reverse_button_var.set(settings.get("reverse_button", 9))  # Default to Button 9
    reverse_button_menu = tk.OptionMenu(reverse_window, reverse_button_var, *list(range(1, 17)))
    reverse_button_menu.grid(row=1, column=1, padx=5, pady=5)

    # Keyboard Clutch Binding
    tk.Label(reverse_window, text="Keyboard Clutch").grid(row=2, column=0, padx=5, pady=5)
    keyboard_clutch_var = tk.StringVar(reverse_window)
    keyboard_clutch_var.set(settings.get("keyboard_clutch", "0"))  # Default to '0'
    tk.Entry(reverse_window, textvariable=keyboard_clutch_var).grid(row=2, column=1, padx=5, pady=5)

    # Keyboard Gear 5 Binding
    tk.Label(reverse_window, text="Keyboard Gear 5").grid(row=3, column=0, padx=5, pady=5)
    keyboard_gear5_var = tk.StringVar(reverse_window)
    keyboard_gear5_var.set(settings.get("keyboard_gear5", "9"))  # Default to '9'
    tk.Entry(reverse_window, textvariable=keyboard_gear5_var).grid(row=3, column=1, padx=5, pady=5)

    # Save Button
    def save_bindings():
        settings["clutch_axis"] = clutch_var.get()
        settings["reverse_button"] = reverse_button_var.get()
        settings["keyboard_clutch"] = keyboard_clutch_var.get()
        settings["keyboard_gear5"] = keyboard_gear5_var.get()
        save_settings(controller_var.get(), settings, profile_var.get())
        reverse_window.destroy()

    tk.Button(reverse_window, text="Save", command=save_bindings).grid(row=4, column=0, columnspan=2, pady=10)

# Button to change reverse bindings
change_bindings_button = tk.Button(frame, text="Change Reverse Bindings", command=open_reverse_bindings_window)
change_bindings_button.grid(row=4, column=2, pady=10)

# Function to toggle Wheelmode and enable/disable related options
def toggle_wheelmode(checkbutton):
    if wheelmode_checkbutton_var.get():
        checkbutton.config(text="(ON)", fg="green")
        enable_wheelmode_options()
    else:
        checkbutton.config(text="(OFF)", fg="red")
        disable_wheelmode_options()

# Function to enable Wheelmode options
def enable_wheelmode_options():
    linearity_entry.config(state=tk.NORMAL)

# Function to disable Wheelmode options
def disable_wheelmode_options():
    linearity_entry.config(state=tk.DISABLED)

# Function to monitor the selected Xbox controller events and control the X axis
def monitor_xbox_controller():
    global current_x_axis_value
    while True:
        selected_controller_name = controller_var.get()
        if selected_controller_name != "Select Controller":
            selected_controller = None
            for controller in controllers:
                if controller.get_name() == selected_controller_name:
                    selected_controller = controller
                    break

            if selected_controller:
                pygame.event.pump()

                # Handle reverse activation
                if selected_controller.get_button(button_binding):  # Use the bound button
                    on_reverse_activate()
                else:
                    on_reverse_deactivate()

                # Handle Wheelmode (X axis control)
                if wheelmode_checkbutton_var.get():
                    try:
                        # Ensure the linearity and smoothing values are updated dynamically
                        linearity = int(linearity_entry.get())
                        linearity = max(50, min(linearity, 150))  # Clamp between 50 and 150
                        
                        smoothing = float(smoothing_entry.get())
                        smoothing = max(0.0, min(smoothing, 1.0))  # Clamp between 0 and 1
                    except ValueError:
                        continue  # Skip the loop iteration if the values are invalid

                    # Get the X axis of the left joystick
                    x_axis_value = selected_controller.get_axis(0)
                    
                    # Apply the linearity curve directly to the x_axis_output
                    x_axis_output = np.sign(x_axis_value) * np.abs(x_axis_value) ** (100 / linearity)

                    # Fix for smoothing = 1.0, apply slight weight to the new input
                    if smoothing >= 1.0:
                        smoothing = 0.95  # Slightly below 1 to allow small new input effects
                    
                    # Apply smoothing to the output, or return to center faster when not steering
                    if x_axis_value != 0:
                        # Normal smoothing when there is steering input
                        x_axis_output = (smoothing * current_x_axis_value) + ((1 - smoothing) * x_axis_output)
                    else:
                        # Return to center with half the smoothing speed (faster)
                        center_smoothing = smoothing / 2
                        x_axis_output = (center_smoothing * current_x_axis_value) + ((1 - center_smoothing) * 0.0)

                    # Ensure the output is within valid bounds (-1 to 1)
                    x_axis_output = max(-1.0, min(1.0, x_axis_output))
                    
                    # Update current value
                    current_x_axis_value = x_axis_output

                    # Scale to vJoy X axis range and send output to vJoy
                    vj.set_axis(pyvjoy.HID_USAGE_X, int((x_axis_output + 1) * 0x4000))  
                    
                    # Update the steering visualization
                    update_steering_visualization(x_axis_output)

        time.sleep(0.01)  # Small delay to prevent CPU overuse
        
# Run the Xbox controller monitoring in a separate thread
def start_monitoring():
    xbox_thread = Thread(target=monitor_xbox_controller)
    xbox_thread.daemon = True
    xbox_thread.start()

# Load all profiles on startup
def load_all_profiles():
    profiles = [f.replace(f"{controller_var.get()}_", "").replace("_settings.json", "") for f in os.listdir(".") if f.startswith(controller_var.get())]
    profile_menu['menu'].delete(0, 'end')
    for profile in profiles:
        profile_menu['menu'].add_command(label=profile, command=lambda p=profile: profile_var.set(p))

# Load profiles and start monitoring on startup
load_all_profiles()
start_monitoring()

# Start monitoring when the dropdown selection changes
controller_var.trace("w", lambda *args: start_monitoring())
profile_var.trace("w", lambda *args: start_monitoring())

# Save the wheelmode setting when the checkbox changes
wheelmode_checkbutton_var.trace("w", lambda *args: settings.update({"wheelmode_enabled": wheelmode_checkbutton_var.get()}) or save_settings(controller_var.get(), settings, profile_var.get()))

# Define the open_url function to open the web browser
def open_url():
    webbrowser.open("https://github.com/BrokenGameNoob/BrokenTC2")

# Create a frame to hold the button and the text
bottom_frame = tk.Frame(root)
bottom_frame.pack(side=tk.BOTTOM, anchor=tk.W, padx=10, pady=10)

# Create the credit label
credit_label = tk.Label(
    bottom_frame, text="Made by Flicction with help from BrokenGameNoob", font=("Helvetica", 10))
credit_label.pack(side=tk.LEFT, padx=10)

# Create the button to open the URL
url_button = tk.Button(
    bottom_frame, text="Check out Clutch helper Software (BTC2)", command=open_url)
url_button.pack(side=tk.RIGHT)

# UI Initialization
def initialize_ui():
    global linearity_entry, smoothing_entry
    
    # Add smoothing entry to the UI
    add_smoothing_entry_to_ui()

# Run the Tkinter event loop
initialize_ui()
root.mainloop()
